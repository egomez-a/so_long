This is my *get_next_line* library as it was when I did this project. See it in is own repository here:

https://github.com/S-LucasSerrano/get_next_line
