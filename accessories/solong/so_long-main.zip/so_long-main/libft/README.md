This is my *libft* library as it was when I did this project. For the latest version of it go to:

https://github.com/S-LucasSerrano/Libft